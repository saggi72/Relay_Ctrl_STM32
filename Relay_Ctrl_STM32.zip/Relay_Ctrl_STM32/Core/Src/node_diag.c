/**
 ******************************************************************************
 * @file    node_diag.c
 * @brief   Node liveness + diagnostics: heartbeat frame and g_nodeDiag.
 *
 *          Why an alive counter and not just "a frame every second"?
 *          A frozen node can keep resending the SAME frame (a stuck TX
 *          mailbox retransmits by itself). A counter that changes proves
 *          the CPU actually ran this code again.
 ******************************************************************************
 */
#include <stdbool.h>
#include "node_diag.h"
#include "can_comm.h"
#include "relay_cfg.h"
#include "relay_dbc.h"

volatile NodeDiag_t g_nodeDiag;

static bool     s_hbSentOnce = false;
static uint32_t s_lastHbMs   = 0U;
static uint8_t  s_nextAlive  = 0U;

/* ------------------------------------------------------------------------ */
/* Reset cause from RCC->CSR (RM0008 §7.3.10). The flags survive the reset  */
/* and stay set until software writes RMVF, so we read them once and clear. */
/* ------------------------------------------------------------------------ */
static uint8_t NodeDiag_ReadResetCause(void)
{
    const uint32_t csr   = RCC->CSR;
    uint8_t        cause = HB_RESET_UNKNOWN;

    /* Order matters: a power-on reset ALSO sets PINRSTF (the internal
     * reset drives NRST low), so POR must be tested before PIN.           */
    if ((csr & RCC_CSR_IWDGRSTF) != 0U)
    {
        cause = HB_RESET_IWDG;
    }
    else if ((csr & RCC_CSR_WWDGRSTF) != 0U)
    {
        cause = HB_RESET_WWDG;
    }
    else if ((csr & RCC_CSR_LPWRRSTF) != 0U)
    {
        cause = HB_RESET_LOW_POWER;
    }
    else if ((csr & RCC_CSR_SFTRSTF) != 0U)
    {
        cause = HB_RESET_SOFTWARE;
    }
    else if ((csr & RCC_CSR_PORRSTF) != 0U)
    {
        cause = HB_RESET_POWER_ON;
    }
    else if ((csr & RCC_CSR_PINRSTF) != 0U)
    {
        cause = HB_RESET_PIN;
    }
    else
    {
        /* no flag set: keep HB_RESET_UNKNOWN */
    }

    RCC->CSR |= RCC_CSR_RMVF;   /* clear -> next reset reports a fresh cause */

    return cause;
}

/* ------------------------------------------------------------------------ */
/* Public API                                                               */
/* ------------------------------------------------------------------------ */
void NodeDiag_Init(void)
{
    g_nodeDiag.loopCount        = 0U;
    g_nodeDiag.uptimeMs         = 0U;
    g_nodeDiag.rxCmdCount       = 0U;
    g_nodeDiag.txStatusCount    = 0U;
    g_nodeDiag.txHeartbeatCount = 0U;
    g_nodeDiag.aliveCounter     = 0U;
    g_nodeDiag.resetCause       = NodeDiag_ReadResetCause();

    s_hbSentOnce = false;            /* first heartbeat goes out at once    */
    s_lastHbMs   = HAL_GetTick();
    s_nextAlive  = 0U;
}

void NodeDiag_OnLoop(uint32_t nowMs)
{
    g_nodeDiag.loopCount++;
    g_nodeDiag.uptimeMs = nowMs;
}

void NodeDiag_OnCmdRx(void)
{
    g_nodeDiag.rxCmdCount++;
}

void NodeDiag_OnStatusTx(void)
{
    g_nodeDiag.txStatusCount++;
}

void NodeDiag_Task(uint32_t nowMs)
{
    const bool due = (!s_hbSentOnce) ||
                     ((uint32_t)(nowMs - s_lastHbMs) >= HEARTBEAT_CYCLE_MS);

    if (due)
    {
        RelayDbc_Heartbeat_t hb;
        uint8_t              data[RELAY_DBC_HEARTBEAT_DLC];

        hb.aliveCounter    = s_nextAlive;
        hb.resetCause      = g_nodeDiag.resetCause;
        hb.rxOverflow      = (CanComm_GetRxOverflowCount() != 0U) ? 1U : 0U;
        hb.feedbackEnabled = (RELAY_FEEDBACK_ENABLE == 1U) ? 1U : 0U;
        hb.uptimeSec       = (uint16_t)(nowMs / 1000U);
        hb.rxCmdCount      = (uint16_t)g_nodeDiag.rxCmdCount;
        CanComm_GetErrorCounters(&hb.tec, &hb.rec);

        RelayDbc_EncodeHeartbeat(&hb, data);

        if (CanComm_Send(RELAY_DBC_HEARTBEAT_ID, data, RELAY_DBC_HEARTBEAT_DLC) == HAL_OK)
        {
            g_nodeDiag.aliveCounter = s_nextAlive;
            g_nodeDiag.txHeartbeatCount++;
            s_nextAlive  = (uint8_t)(s_nextAlive + 1U);   /* 255 -> 0 */
            s_hbSentOnce = true;
            s_lastHbMs   = nowMs;
        }
        /* else: mailboxes full -> still 'due', retried on the next loop.
         *       The counter only moves when a frame really left the CPU.  */
    }
}
