/**
 ******************************************************************************
 * @file    app.c
 * @brief   Application layer of the STM32 Relay Node.
 *
 *          Main loop job (super-loop, no RTOS):
 *            1. Take received commands from the CAN queue -> relays
 *            2. Supervise relay feedback
 *            3. Send STM32_Relay_Status: every 100 ms AND immediately
 *               when any relay status changes
 *            4. Send STM32_Relay_Heartbeat: once at boot, then every 1 s
 *            5. Blink the status LED (slow = OK, fast = CAN bus error)
 ******************************************************************************
 */
#include <stdbool.h>
#include "app.h"
#include "can_comm.h"
#include "node_diag.h"
#include "relay_ctrl.h"
#include "relay_dbc.h"
#include "relay_cfg.h"

static uint8_t  s_lastStatusSent = 0U;
static bool     s_statusSentOnce = false;
static uint32_t s_lastStatusTxMs = 0U;
static uint32_t s_lastLedMs      = 0U;

/* ------------------------------------------------------------------------ */
static void App_HandleFrame(const CanFrame_t *frame)
{
    uint8_t ch;

    /* The HW filter already passes only 0x100; checking again in software
     * is cheap and protects us if someone changes the filter later.       */
    if ((frame->stdId == RELAY_DBC_CMD_ID) && (frame->dlc >= RELAY_DBC_CMD_DLC))
    {
        NodeDiag_OnCmdRx();

        for (ch = 0U; ch < RELAY_DBC_NUM_RELAYS; ch++)
        {
            Relay_ApplyCommand(ch, RelayDbc_GetControl(frame->data[0], ch));
        }
    }
}

static uint8_t App_BuildStatusByte(void)
{
    uint8_t byte0 = 0U;
    uint8_t ch;

    for (ch = 0U; ch < RELAY_DBC_NUM_RELAYS; ch++)
    {
        byte0 = RelayDbc_SetStatus(byte0, ch, Relay_GetStatus(ch));
    }

    return byte0;
}

static void App_StatusTask(uint32_t nowMs)
{
    const uint8_t status   = App_BuildStatusByte();
    const bool    changed  = (!s_statusSentOnce) || (status != s_lastStatusSent);
    const bool    cycleDue = ((uint32_t)(nowMs - s_lastStatusTxMs) >= STATUS_CYCLE_MS);

    if (changed || cycleDue)
    {
        const uint8_t data[RELAY_DBC_STATUS_DLC] = { status };

        if (CanComm_Send(RELAY_DBC_STATUS_ID, data, RELAY_DBC_STATUS_DLC) == HAL_OK)
        {
            s_lastStatusSent = status;
            s_statusSentOnce = true;
            s_lastStatusTxMs = nowMs;
            NodeDiag_OnStatusTx();
        }
        /* else: mailboxes full -> 'changed'/'cycleDue' stay true,
         *       we simply retry on the next loop                          */
    }
}

static void App_LedTask(uint32_t nowMs)
{
    const uint32_t period = CanComm_IsBusError() ? LED_BUS_ERROR_MS : LED_HEARTBEAT_MS;

    if ((uint32_t)(nowMs - s_lastLedMs) >= period)
    {
        s_lastLedMs = nowMs;
        HAL_GPIO_TogglePin(LED_STATUS_GPIO_Port, LED_STATUS_Pin);
    }
}

/* ------------------------------------------------------------------------ */
/* Public API                                                               */
/* ------------------------------------------------------------------------ */
void App_Init(CAN_HandleTypeDef *hcan)
{
    NodeDiag_Init();                   /* first: latch the reset cause     */
    Relay_Init();

    if (CanComm_Init(hcan) != HAL_OK)
    {
        Error_Handler();
    }

    s_statusSentOnce = false;          /* first status goes out at once    */
    s_lastStatusTxMs = HAL_GetTick();
    s_lastLedMs      = HAL_GetTick();
}

void App_Run(void)
{
    CanFrame_t     frame;
    const uint32_t nowMs = HAL_GetTick();

    NodeDiag_OnLoop(nowMs);

    while (CanComm_Receive(&frame))
    {
        App_HandleFrame(&frame);
    }

    Relay_Task(nowMs);
    App_StatusTask(nowMs);             /* status first: it gets a mailbox  */
    NodeDiag_Task(nowMs);              /* before the heartbeat does        */
    App_LedTask(nowMs);
}
