/**
 ******************************************************************************
 * @file    can_comm.c
 * @brief   Thin CAN layer on top of HAL bxCAN (STM32F1).
 *
 *          RX path:  bus -> HW filter (only 0x100) -> FIFO0 -> interrupt
 *                    -> HAL_CAN_RxFifo0MsgPendingCallback() -> s_rxQueue
 *                    -> CanComm_Receive() in the main loop
 *
 *          The ISR only copies the frame. All decoding / relay switching
 *          happens in the main loop. Keep ISRs short.
 *
 *          Queue = single producer (ISR) / single consumer (main loop):
 *            ISR  writes only s_rxHead, main loop writes only s_rxTail
 *            -> no need to disable interrupts.
 ******************************************************************************
 */
#include <string.h>
#include "can_comm.h"
#include "relay_cfg.h"
#include "relay_dbc.h"

#if ((CAN_RX_QUEUE_LEN == 0U) || ((CAN_RX_QUEUE_LEN & (CAN_RX_QUEUE_LEN - 1U)) != 0U))
#error "CAN_RX_QUEUE_LEN must be a power of 2"
#endif

#define CAN_RX_QUEUE_MASK   ((uint8_t)(CAN_RX_QUEUE_LEN - 1U))
#define CAN_MAX_DLC         (8U)

static CAN_HandleTypeDef *s_hcan = NULL;

static CanFrame_t        s_rxQueue[CAN_RX_QUEUE_LEN];
static volatile uint8_t  s_rxHead     = 0U;   /* written by ISR only       */
static volatile uint8_t  s_rxTail     = 0U;   /* written by main loop only */
static volatile uint32_t s_rxOverflow = 0U;

/* ------------------------------------------------------------------------ */
/* Hardware filter: accept ONLY standard data frame ID 0x100                */
/*                                                                          */
/* 32-bit filter register layout (RM0008, bxCAN):                           */
/*   bit 31..21 STID[10:0] | 20..3 EXID[17:0] | 2 IDE | 1 RTR | 0 -         */
/*   FilterIdHigh = upper 16 bits, FilterIdLow = lower 16 bits              */
/* ------------------------------------------------------------------------ */
static HAL_StatusTypeDef CanComm_ConfigFilter(CAN_HandleTypeDef *hcan)
{
    CAN_FilterTypeDef filter;

    filter.FilterBank           = 0U;
    filter.FilterMode           = CAN_FILTERMODE_IDMASK;
    filter.FilterScale          = CAN_FILTERSCALE_32BIT;

    filter.FilterIdHigh         = (uint32_t)(RELAY_DBC_CMD_ID << 5U); /* 0x2000 */
    filter.FilterIdLow          = 0x0000U;      /* IDE = 0 (std), RTR = 0 (data) */

    filter.FilterMaskIdHigh     = (uint32_t)(0x7FFU << 5U);           /* 0xFFE0 */
    filter.FilterMaskIdLow      = 0x0006U;      /* also compare IDE and RTR      */

    filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
    filter.FilterActivation     = CAN_FILTER_ENABLE;
    filter.SlaveStartFilterBank = 14U;          /* only meaningful with CAN2     */

    return HAL_CAN_ConfigFilter(hcan, &filter);
}

/* ------------------------------------------------------------------------ */
/* Public API                                                               */
/* ------------------------------------------------------------------------ */
HAL_StatusTypeDef CanComm_Init(CAN_HandleTypeDef *hcan)
{
    HAL_StatusTypeDef st = HAL_ERROR;

    if (hcan != NULL)
    {
        s_hcan       = hcan;
        s_rxHead     = 0U;
        s_rxTail     = 0U;
        s_rxOverflow = 0U;

        st = CanComm_ConfigFilter(hcan);

        if (st == HAL_OK)
        {
            st = HAL_CAN_Start(hcan);
        }

        if (st == HAL_OK)
        {
            st = HAL_CAN_ActivateNotification(hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
        }
    }

    return st;
}

bool CanComm_Receive(CanFrame_t *frame)
{
    bool          gotFrame = false;
    const uint8_t tail     = s_rxTail;

    if ((frame != NULL) && (tail != s_rxHead))
    {
        __DMB();                    /* read head BEFORE reading the slot   */
        *frame   = s_rxQueue[tail];
        s_rxTail = (uint8_t)((tail + 1U) & CAN_RX_QUEUE_MASK);
        gotFrame = true;
    }

    return gotFrame;
}

HAL_StatusTypeDef CanComm_Send(uint32_t stdId, const uint8_t *data, uint8_t dlc)
{
    HAL_StatusTypeDef   st = HAL_ERROR;
    CAN_TxHeaderTypeDef txHeader;
    uint8_t             txData[CAN_MAX_DLC] = { 0U };
    uint32_t            txMailbox;

    if ((s_hcan != NULL) && (data != NULL) && (dlc <= CAN_MAX_DLC))
    {
        if (HAL_CAN_GetTxMailboxesFreeLevel(s_hcan) == 0U)
        {
            /* 3 mailboxes full: bus busy, no ACK, or cable unplugged.
             * Do NOT wait here - the main loop retries next time.         */
            st = HAL_BUSY;
        }
        else
        {
            txHeader.StdId              = stdId;
            txHeader.ExtId              = 0U;
            txHeader.IDE                = CAN_ID_STD;
            txHeader.RTR                = CAN_RTR_DATA;
            txHeader.DLC                = dlc;
            txHeader.TransmitGlobalTime = DISABLE;

            /* local copy: works with both old (non-const) and new (const)
             * HAL_CAN_AddTxMessage() prototypes                            */
            (void)memcpy(txData, data, dlc);

            st = HAL_CAN_AddTxMessage(s_hcan, &txHeader, txData, &txMailbox);
        }
    }

    return st;
}

bool CanComm_IsBusError(void)
{
    bool busError = false;

    if (s_hcan != NULL)
    {
        const uint32_t esr = s_hcan->Instance->ESR;
        busError = ((esr & (CAN_ESR_BOFF | CAN_ESR_EPVF)) != 0U);
    }

    return busError;
}

uint32_t CanComm_GetRxOverflowCount(void)
{
    return s_rxOverflow;
}

void CanComm_GetErrorCounters(uint8_t *tec, uint8_t *rec)
{
    uint32_t esr = 0U;

    if (s_hcan != NULL)
    {
        esr = s_hcan->Instance->ESR;
    }

    if (tec != NULL)
    {
        *tec = (uint8_t)((esr & CAN_ESR_TEC_Msk) >> CAN_ESR_TEC_Pos);
    }

    if (rec != NULL)
    {
        *rec = (uint8_t)((esr & CAN_ESR_REC_Msk) >> CAN_ESR_REC_Pos);
    }
}

/* ------------------------------------------------------------------------ */
/* HAL callback (overrides the __weak one). Runs in interrupt context:      */
/* USB_LP_CAN1_RX0_IRQHandler -> HAL_CAN_IRQHandler -> here                 */
/* ------------------------------------------------------------------------ */
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rxHeader;
    uint8_t             rxData[CAN_MAX_DLC];

    /* Drain everything that is in FIFO0 (up to 3 frames in hardware) */
    while (HAL_CAN_GetRxFifoFillLevel(hcan, CAN_RX_FIFO0) > 0U)
    {
        if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, rxData) != HAL_OK)
        {
            break;
        }

        if ((rxHeader.IDE == CAN_ID_STD) && (rxHeader.RTR == CAN_RTR_DATA))
        {
            const uint8_t head = s_rxHead;
            const uint8_t next = (uint8_t)((head + 1U) & CAN_RX_QUEUE_MASK);

            if (next == s_rxTail)
            {
                s_rxOverflow++;     /* queue full: main loop is too slow   */
            }
            else
            {
                CanFrame_t *slot = &s_rxQueue[head];

                slot->stdId = rxHeader.StdId;
                slot->dlc   = (rxHeader.DLC > CAN_MAX_DLC) ? (uint8_t)CAN_MAX_DLC
                                                           : (uint8_t)rxHeader.DLC;
                (void)memcpy(slot->data, rxData, CAN_MAX_DLC);

                __DMB();            /* slot fully written BEFORE head moves */
                s_rxHead = next;
            }
        }
    }
}
