/**
 ******************************************************************************
 * @file    relay_ctrl.c
 * @brief   Relay driver: executes commands and computes per-relay status.
 *
 *          Two kinds of state per relay:
 *            cmdOn : what the master WANTS (last ON/OFF/TOGGLE)
 *            fail  : feedback disagreed with cmdOn for RELAY_FB_FAIL_TIME_MS
 *
 *          Only called from the main loop (never from an ISR), so no
 *          critical sections are needed here.
 ******************************************************************************
 */
#include <stdbool.h>
#include "relay_ctrl.h"
#include "relay_cfg.h"
#include "relay_dbc.h"

typedef struct
{
    GPIO_TypeDef *port;
    uint16_t      pin;
} RelayPin_t;

typedef struct
{
    bool     cmdOn;            /* commanded state                          */
    bool     fail;             /* reported as RELAY_STS_FAIL               */
    bool     mismatch;         /* feedback currently != command            */
    uint32_t mismatchStartMs;  /* when the current mismatch began          */
} RelayState_t;

static const RelayPin_t s_relayOut[RELAY_DBC_NUM_RELAYS] = { RELAY_CFG_TABLE };

#if (RELAY_FEEDBACK_ENABLE == 1U)
static const RelayPin_t s_relayFb[RELAY_DBC_NUM_RELAYS] = { RELAY_FB_CFG_TABLE };
#endif

static RelayState_t s_relay[RELAY_DBC_NUM_RELAYS];

/* ------------------------------------------------------------------------ */
/* Low level: logical ON/OFF -> electrical level (hides active LOW/HIGH)    */
/* ------------------------------------------------------------------------ */
static void Relay_WritePin(uint8_t ch, bool on)
{
    GPIO_PinState level;

#if (RELAY_ACTIVE_LOW == 1U)
    level = on ? GPIO_PIN_RESET : GPIO_PIN_SET;
#else
    level = on ? GPIO_PIN_SET : GPIO_PIN_RESET;
#endif

    HAL_GPIO_WritePin(s_relayOut[ch].port, s_relayOut[ch].pin, level);
}

#if (RELAY_FEEDBACK_ENABLE == 1U)
/* Returns true when the relay contact is really CLOSED */
static bool Relay_ReadFeedback(uint8_t ch)
{
    const GPIO_PinState level = HAL_GPIO_ReadPin(s_relayFb[ch].port, s_relayFb[ch].pin);

#if (RELAY_FB_ACTIVE_LOW == 1U)
    return (level == GPIO_PIN_RESET);
#else
    return (level == GPIO_PIN_SET);
#endif
}
#endif

static void Relay_Set(uint8_t ch, bool on)
{
    /* Restart the feedback supervision window only on a REAL change.
     * If we restarted it on every repeated ON, a master that sends ON
     * every 50 ms would keep resetting the window and FAIL could never
     * be detected.                                                        */
    if (s_relay[ch].cmdOn != on)
    {
        s_relay[ch].cmdOn    = on;
        s_relay[ch].mismatch = false;
    }

    /* Rewriting the same level is harmless and refreshes the output.      */
    Relay_WritePin(ch, on);
}

/* ------------------------------------------------------------------------ */
/* Public API                                                               */
/* ------------------------------------------------------------------------ */
void Relay_Init(void)
{
    uint8_t ch;

    for (ch = 0U; ch < RELAY_DBC_NUM_RELAYS; ch++)
    {
        s_relay[ch].cmdOn           = false;
        s_relay[ch].fail            = false;
        s_relay[ch].mismatch        = false;
        s_relay[ch].mismatchStartMs = 0U;
        Relay_WritePin(ch, false);          /* safe state: all OFF         */
    }
}

void Relay_ApplyCommand(uint8_t ch, uint8_t cmd)
{
    if (ch < RELAY_DBC_NUM_RELAYS)
    {
        switch (cmd)
        {
            case RELAY_CMD_ON:
                Relay_Set(ch, true);
                break;

            case RELAY_CMD_OFF:
                Relay_Set(ch, false);
                break;

            case RELAY_CMD_TOGGLE:
                Relay_Set(ch, !s_relay[ch].cmdOn);
                break;

            case RELAY_CMD_NO_ACTION:
            default:
                /* keep current state */
                break;
        }
    }
}

void Relay_Task(uint32_t nowMs)
{
#if (RELAY_FEEDBACK_ENABLE == 1U)
    uint8_t ch;

    for (ch = 0U; ch < RELAY_DBC_NUM_RELAYS; ch++)
    {
        RelayState_t *r   = &s_relay[ch];
        const bool    fbOn = Relay_ReadFeedback(ch);

        if (fbOn == r->cmdOn)
        {
            /* Contact agrees with the command -> healthy */
            r->mismatch = false;
            r->fail     = false;
        }
        else if (!r->mismatch)
        {
            /* First sample that disagrees: start the timer.
             * Normal right after switching (relay needs ~10 ms to move).   */
            r->mismatch        = true;
            r->mismatchStartMs = nowMs;
        }
        else if ((uint32_t)(nowMs - r->mismatchStartMs) >= RELAY_FB_FAIL_TIME_MS)
        {
            /* Disagrees for too long -> stuck / welded / no supply */
            r->fail = true;
        }
        else
        {
            /* still inside the allowed switching time */
        }
    }
#else
    (void)nowMs;                            /* no feedback: nothing to do  */
#endif
}

uint8_t Relay_GetStatus(uint8_t ch)
{
    uint8_t status = RELAY_STS_FAIL;

    if (ch < RELAY_DBC_NUM_RELAYS)
    {
        if (s_relay[ch].fail)
        {
            status = RELAY_STS_FAIL;
        }
        else
        {
            status = s_relay[ch].cmdOn ? RELAY_STS_ON : RELAY_STS_OFF;
        }
    }

    return status;
}
