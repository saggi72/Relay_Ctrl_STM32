/**
 ******************************************************************************
 * @file    node_diag.h
 * @brief   "Is the node alive?" - two ways to see it:
 *
 *          1. On the bus : STM32_Relay_Heartbeat (0x102) every 1000 ms,
 *                          with an alive counter that must keep counting.
 *          2. In the IDE : the global variable g_nodeDiag. Add it ONCE in
 *                          Live Expressions and expand it - every field
 *                          below is visible while the program runs.
 ******************************************************************************
 */
#ifndef NODE_DIAG_H
#define NODE_DIAG_H

#include <stdint.h>

typedef struct
{
    uint32_t loopCount;         /* +1 every App_Run() pass  -> main loop alive */
    uint32_t uptimeMs;          /* HAL_GetTick() seen by the last loop pass    */
    uint32_t rxCmdCount;        /* valid MCU_Relay_Command frames processed    */
    uint32_t txStatusCount;     /* STM32_Relay_Status frames queued            */
    uint32_t txHeartbeatCount;  /* STM32_Relay_Heartbeat frames queued         */
    uint8_t  aliveCounter;      /* alive counter carried by the last heartbeat */
    uint8_t  resetCause;        /* HB_RESET_xxx, latched once at boot          */
} NodeDiag_t;

/* Global on purpose (not static): unique name, easy to find in the debugger.
 * volatile: the debugger reads it from RAM behind the CPU's back, so every
 * write must really reach RAM, even in an optimised (Release) build.        */
extern volatile NodeDiag_t g_nodeDiag;

/* Latch + clear the reset flags, reset counters. Call FIRST in App_Init().  */
void NodeDiag_Init(void);

/* Bookkeeping hooks called by app.c                                        */
void NodeDiag_OnLoop(uint32_t nowMs);
void NodeDiag_OnCmdRx(void);
void NodeDiag_OnStatusTx(void);

/* Sends the heartbeat: once right after boot, then every HEARTBEAT_CYCLE_MS */
void NodeDiag_Task(uint32_t nowMs);

#endif /* NODE_DIAG_H */