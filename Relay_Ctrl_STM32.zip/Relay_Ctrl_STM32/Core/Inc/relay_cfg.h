/**
 ******************************************************************************
 * @file    relay_cfg.h
 * @brief   Hardware + timing configuration of the STM32 Relay Node.
 *
 *          Pin names (RELAY1_Pin, FB1_Pin, LED_STATUS_Pin, ...) come from the
 *          User Labels set in CubeMX -> they are generated into main.h.
 *          Change the hardware here, never inside relay_ctrl.c / app.c.
 ******************************************************************************
 */
#ifndef RELAY_CFG_H
#define RELAY_CFG_H

#include "main.h"

/* ------------------------- Relay outputs -------------------------------- */
/* 1U: relay module is active LOW (IN = 0 V -> relay energized). Most
 *     4-channel opto relay modules are active LOW.
 * 0U: relay is driven HIGH-active (e.g. your own transistor driver).     */
#define RELAY_ACTIVE_LOW            (1U)

#define RELAY_CFG_TABLE                         \
    { RELAY1_GPIO_Port, RELAY1_Pin },           \
    { RELAY2_GPIO_Port, RELAY2_Pin },           \
    { RELAY3_GPIO_Port, RELAY3_Pin },           \
    { RELAY4_GPIO_Port, RELAY4_Pin }

/* ------------------------- Relay feedback ------------------------------- */
/* 1U: read a real feedback signal per relay (auxiliary contact, opto on the
 *     load side, current sense...) -> enables FAIL detection.
 * 0U: no feedback wired -> status is reported from the commanded state and
 *     FAIL is never reported.                                              */
#define RELAY_FEEDBACK_ENABLE       (0U)

/* 1U: feedback input reads LOW when the relay contact is CLOSED
 *     (contact pulls the input to GND, internal pull-up enabled).          */
#define RELAY_FB_ACTIVE_LOW         (1U)

#define RELAY_FB_CFG_TABLE                      \
    { FB1_GPIO_Port, FB1_Pin },                 \
    { FB2_GPIO_Port, FB2_Pin },                 \
    { FB3_GPIO_Port, FB3_Pin },                 \
    { FB4_GPIO_Port, FB4_Pin }

/* Feedback must disagree with the command for this long before FAIL.
 * Must be longer than the relay operate/release time (~10-15 ms) + bounce. */
#define RELAY_FB_FAIL_TIME_MS       (100U)

/* ------------------------- CAN timing ----------------------------------- */
#define STATUS_CYCLE_MS             (100U)   /* cyclic STM32_Relay_Status    */
#define HEARTBEAT_CYCLE_MS          (1000U)  /* cyclic STM32_Relay_Heartbeat */
#define CAN_RX_QUEUE_LEN            (8U)     /* must be a power of 2         */

/* ------------------------- Status LED (PC13 on Blue Pill) --------------- */
#define LED_HEARTBEAT_MS            (500U)   /* normal: slow blink           */
#define LED_BUS_ERROR_MS            (100U)   /* bus-off / error passive      */

#endif /* RELAY_CFG_H */
