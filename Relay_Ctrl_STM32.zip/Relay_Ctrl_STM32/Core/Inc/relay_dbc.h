/**
 ******************************************************************************
 * @file    relay_dbc.h
 * @brief   CAN signal definitions for the Relay network (mirror of the DBC).
 *
 *          Source DBC: nodes MasterNode / STM32_Relay_Node (STM32_Relay.dbc)
 *            BO_ 256 MCU_Relay_Command    : 1 byte, MasterNode       -> STM32
 *            BO_ 257 STM32_Relay_Status   : 1 byte, STM32_Relay_Node -> Master
 *            BO_ 258 STM32_Relay_Heartbeat: 8 byte, STM32_Relay_Node -> Master
 *
 *          Byte 0 layout (both messages, Intel / little endian, unsigned):
 *            bit 7..6 | bit 5..4 | bit 3..2 | bit 1..0
 *            Relay_4  | Relay_3  | Relay_2  | Relay_1
 *
 *          Rule: this file is the ONLY place that knows bit positions.
 *          If the DBC changes, only this file changes.
 ******************************************************************************
 */
#ifndef RELAY_DBC_H
#define RELAY_DBC_H

#include <stdint.h>

/* ---------------------------- Messages ---------------------------------- */
#define RELAY_DBC_CMD_ID            (0x100U)  /* BO_ 256 MCU_Relay_Command   */
#define RELAY_DBC_CMD_DLC           (1U)
#define RELAY_DBC_STATUS_ID         (0x101U)  /* BO_ 257 STM32_Relay_Status  */
#define RELAY_DBC_STATUS_DLC        (1U)
#define RELAY_DBC_HEARTBEAT_ID      (0x102U)  /* BO_ 258 STM32_Relay_Heartbeat */
#define RELAY_DBC_HEARTBEAT_DLC     (8U)

/* ---------------------------- Signals ----------------------------------- */
#define RELAY_DBC_NUM_RELAYS        (4U)
#define RELAY_DBC_SIG_LENGTH        (2U)      /* every signal is 2 bits      */
#define RELAY_DBC_SIG_MASK          (0x03U)

/* Start bits exactly as written in the DBC (SG_ ... : start|length@1+)    */
#define RELAY_DBC_CH1_START_BIT     (0U)      /* Relay_Control_1 / Status_1  */
#define RELAY_DBC_CH2_START_BIT     (2U)      /* Relay_Control_2 / Status_2  */
#define RELAY_DBC_CH3_START_BIT     (4U)      /* Relay_Control_3 / Status_3  */
#define RELAY_DBC_CH4_START_BIT     (6U)      /* Relay_Control_4 / Status_4  */

/* VAL_ 256 Relay_Control_x */
#define RELAY_CMD_NO_ACTION         (0U)
#define RELAY_CMD_ON                (1U)
#define RELAY_CMD_OFF               (2U)
#define RELAY_CMD_TOGGLE            (3U)

/* VAL_ 257 Relay_Status_x (value 3 is not defined in the DBC) */
#define RELAY_STS_OFF               (0U)
#define RELAY_STS_ON                (1U)
#define RELAY_STS_FAIL              (2U)

/* ------------------- STM32_Relay_Heartbeat (0x102) ---------------------- */
/*  Byte | Bits | Signal              | Meaning
 *  -----+------+---------------------+-------------------------------------
 *   0   | 0..7 | HB_AliveCounter     | +1 per frame, wraps 255 -> 0
 *   1   | 0..3 | HB_ResetCause       | why the MCU (re)started, see below
 *   1   |  4   | HB_RxOverflow       | 1 = a command frame was ever dropped
 *   1   |  5   | HB_FeedbackEnabled  | 1 = firmware built with feedback/FAIL
 *  2..3 | 16 b | HB_UptimeSec        | seconds since boot (wraps ~18.2 h)
 *  4..5 | 16 b | HB_RxCmdCount       | valid 0x100 frames processed (wraps)
 *   6   | 0..7 | HB_TEC              | CAN transmit error counter
 *   7   | 0..7 | HB_REC              | CAN receive error counter
 *  All Intel (little endian), unsigned.                                    */

/* VAL_ 258 HB_ResetCause */
#define HB_RESET_UNKNOWN            (0U)
#define HB_RESET_POWER_ON           (1U)      /* power applied / brown-out   */
#define HB_RESET_PIN                (2U)      /* RESET button / NRST pin     */
#define HB_RESET_SOFTWARE           (3U)      /* NVIC_SystemReset, debugger  */
#define HB_RESET_IWDG               (4U)      /* independent watchdog        */
#define HB_RESET_WWDG               (5U)      /* window watchdog             */
#define HB_RESET_LOW_POWER          (6U)      /* low-power management reset  */

typedef struct
{
    uint8_t  aliveCounter;
    uint8_t  resetCause;        /* 4 bit used */
    uint8_t  rxOverflow;        /* 1 bit used */
    uint8_t  feedbackEnabled;   /* 1 bit used */
    uint16_t uptimeSec;
    uint16_t rxCmdCount;
    uint8_t  tec;
    uint8_t  rec;
} RelayDbc_Heartbeat_t;

static inline void RelayDbc_EncodeHeartbeat(const RelayDbc_Heartbeat_t *hb,
                                            uint8_t data[RELAY_DBC_HEARTBEAT_DLC])
{
    data[0] = hb->aliveCounter;
    data[1] = (uint8_t)((hb->resetCause & 0x0FU)
                      | ((hb->rxOverflow & 0x01U) << 4U)
                      | ((hb->feedbackEnabled & 0x01U) << 5U));
    data[2] = (uint8_t)(hb->uptimeSec & 0xFFU);
    data[3] = (uint8_t)(hb->uptimeSec >> 8U);
    data[4] = (uint8_t)(hb->rxCmdCount & 0xFFU);
    data[5] = (uint8_t)(hb->rxCmdCount >> 8U);
    data[6] = hb->tec;
    data[7] = hb->rec;
}

/* ---------------------------- Helpers ----------------------------------- */
/* Channel index ch is 0-based: ch = 0 -> Relay_1 ... ch = 3 -> Relay_4    */
static inline uint8_t RelayDbc_StartBit(uint8_t ch)
{
    static const uint8_t startBit[RELAY_DBC_NUM_RELAYS] = {
        RELAY_DBC_CH1_START_BIT, RELAY_DBC_CH2_START_BIT,
        RELAY_DBC_CH3_START_BIT, RELAY_DBC_CH4_START_BIT
    };
    return startBit[ch];
}

/* Decode one Relay_Control_x signal from byte 0 of MCU_Relay_Command */
static inline uint8_t RelayDbc_GetControl(uint8_t byte0, uint8_t ch)
{
    return (uint8_t)((byte0 >> RelayDbc_StartBit(ch)) & RELAY_DBC_SIG_MASK);
}

/* Encode one Relay_Status_x signal into byte 0 of STM32_Relay_Status */
static inline uint8_t RelayDbc_SetStatus(uint8_t byte0, uint8_t ch, uint8_t status)
{
    const uint8_t shift = RelayDbc_StartBit(ch);
    const uint8_t clearMask = (uint8_t)~(uint8_t)(RELAY_DBC_SIG_MASK << shift);

    return (uint8_t)((byte0 & clearMask) |
                     (uint8_t)((status & RELAY_DBC_SIG_MASK) << shift));
}

#endif /* RELAY_DBC_H */
