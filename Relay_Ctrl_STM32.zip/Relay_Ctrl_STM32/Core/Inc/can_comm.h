/**
 ******************************************************************************
 * @file    can_comm.h
 * @brief   Thin CAN layer on top of HAL bxCAN:
 *          - hardware filter for the command ID
 *          - RX FIFO0 interrupt -> small software queue (ISR stays short)
 *          - non-blocking transmit
 ******************************************************************************
 */
#ifndef CAN_COMM_H
#define CAN_COMM_H

#include <stdint.h>
#include <stdbool.h>
#include "main.h"

typedef struct
{
    uint32_t stdId;
    uint8_t  dlc;
    uint8_t  data[8];
} CanFrame_t;

/* Configure filter, start bxCAN, enable RX FIFO0 interrupt.               */
HAL_StatusTypeDef CanComm_Init(CAN_HandleTypeDef *hcan);

/* Take one received frame from the queue. Returns false if empty.         */
bool              CanComm_Receive(CanFrame_t *frame);

/* Queue one standard data frame for transmission. Returns HAL_BUSY when
 * all 3 TX mailboxes are full (caller simply retries next loop).         */
HAL_StatusTypeDef CanComm_Send(uint32_t stdId, const uint8_t *data, uint8_t dlc);

/* true when the controller is bus-off or error passive (wiring problem).  */
bool              CanComm_IsBusError(void);

/* Number of frames dropped because the software queue was full.          */
uint32_t          CanComm_GetRxOverflowCount(void);

/* Read TEC / REC from the bxCAN ESR register (either pointer may be NULL). */
void              CanComm_GetErrorCounters(uint8_t *tec, uint8_t *rec);

#endif /* CAN_COMM_H */
