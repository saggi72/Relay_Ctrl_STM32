/**
 ******************************************************************************
 * @file    app.h
 * @brief   Application layer of the STM32 Relay Node.
 *          main.c only calls App_Init() once and App_Run() forever.
 ******************************************************************************
 */
#ifndef APP_H
#define APP_H

#include "main.h"

/* Pass the CubeMX handle in (no 'extern hcan' hidden inside app.c) */
void App_Init(CAN_HandleTypeDef *hcan);
void App_Run(void);

#endif /* APP_H */
