/**
 ******************************************************************************
 * @file    relay_ctrl.h
 * @brief   Relay driver: executes commands and computes per-relay status.
 *          Knows GPIO, knows nothing about CAN.
 ******************************************************************************
 */
#ifndef RELAY_CTRL_H
#define RELAY_CTRL_H

#include <stdint.h>

/* Put every relay in the safe state (OFF). Call once after MX_GPIO_Init(). */
void    Relay_Init(void);

/* Execute one Relay_Control_x value (RELAY_CMD_xxx) on channel ch (0..3). */
void    Relay_ApplyCommand(uint8_t ch, uint8_t cmd);

/* Feedback supervision. Call periodically from the main loop.            */
void    Relay_Task(uint32_t nowMs);

/* Current status of channel ch: RELAY_STS_OFF / _ON / _FAIL.             */
uint8_t Relay_GetStatus(uint8_t ch);

#endif /* RELAY_CTRL_H */
